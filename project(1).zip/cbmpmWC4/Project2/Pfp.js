import React from "react"


export default function Pfp (){
     return(
         <nav>
         <img src = "./images/natsu.jpg" width="300px" height="300px"/>
         <h1> Kafka Hibino </h1>
         <h2> Frontend Developer </h2>
         <h3> Kafkahibino.website </h3>
         </nav>
         
     )   
}