import React from "react"

export default function Intrests(){
    return(
        <main>
        <h1> Intersts </h1>
        <p>
        Food expert ,Music Scholar ,Reader , Internet fanatic ,
        Bacon buff , Entrepreneur , Travel geek , Pop culture ninja
        Coffee fanatic.
        </p>
       </main>
        
    )
}