import React from "react"


export default function Foot(){
    return(
        <footer>
       <img src = "./images/facebook.svg" />
       <img src ="./images/instagram.svg" />
       <img src ="./images/square-twitter.svg" />
       <img src = "./images/github.svg" />
       <img src = "./images/linkedin.svg" />
       </footer>
    )  
}