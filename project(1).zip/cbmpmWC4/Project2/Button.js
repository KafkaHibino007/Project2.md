import React from "react"

export default function Button(){
    return(
        <div>
       <button id ="mail"><img src="./images/envelope-solid.svg"  /> Email </button>
       <button  id="Link"><img src = "./images/linkedln.svg"/> Linkedin </button>
       </div>
      
    )
}
