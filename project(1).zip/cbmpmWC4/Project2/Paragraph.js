import React from "react"

export default function Paragraph(){
    return(
        <main>
        <h1> About </h1>
        <p> I m the frontend developer with particular intrest
           in making things simple and automating daily tasks.
           i try to keep up with security and best practices ,
           and am always looking for the new things to learn .
           </p>
        </main> 
    ) 
}